package com.acadgild.myfirstapp.assignmnet3;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second_layout);
         final EditText ed1 = (EditText)findViewById(R.id.ed1);
        final int a1 = Integer.parseInt(ed1.getText().toString());
        final EditText ed2 = (EditText)findViewById(R.id.ed2);
        final int a2 = Integer.parseInt(ed2.getText().toString());
        final EditText ed3 = (EditText)findViewById(R.id.ed3);
        final int a3 = Integer.parseInt(ed3.getText().toString());
        final EditText ed4 = (EditText)findViewById(R.id.ed4);
        final int a4 = Integer.parseInt(ed4.getText().toString());
        final EditText ed5 = (EditText)findViewById(R.id.ed5);
        final int a5 = Integer.parseInt(ed5.getText().toString());

        Button button = (Button)findViewById(R.id.button1);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


            }
        });
        Button button1 = (Button)findViewById(R.id.button2);

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ed1.setText("");
                ed2.setText("");
                ed3.setText("");
                ed4.setText("");
                ed5.setText("");
            }
        });

    }

}
